"""Hawk TUI - TikTok video creator with Replicate + FFmpeg."""
__version__ = "1.0.0"
