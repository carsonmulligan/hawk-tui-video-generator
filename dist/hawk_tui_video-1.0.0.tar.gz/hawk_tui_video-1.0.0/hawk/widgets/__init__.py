"""Hawk TUI widgets."""
